package de.maeddes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceHelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceHelloWorldApplication.class, args);
	}
}
